<?php
/**
 * @author      Tulio de Melo | Caravel Core Team
 * @copyright   2023 Caravel (https://caravel.com.br)
 * @license     Caravel Proprietary
 * @link        https://caravel.com.br
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Ecritel_CmsPageAuthor',
    __DIR__
);
